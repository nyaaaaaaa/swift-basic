//
//  ViewController.swift
//  UILabel
//
//  Created by にゃー on 2016/03/21.
//  Copyright © 2016年 nyaaaaa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backLabel: UILabel!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        label.text = "Hello Word"
        
        backLabel.text = "こんにちは世界"
        //#99ccff
        backLabel.textColor = UIColor(red:153.0/255.0, green:204.0/255.0, blue:255.0/255.0, alpha:0.8)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

